package com.app.yourvideoschannel.models;

public class Settings {
    private String privacy_policy;

    public String getPrivacy_policy() {
        return privacy_policy;
    }

    public void setPrivacy_policy(String privacy_policy) {
        this.privacy_policy = privacy_policy;
    }

}
