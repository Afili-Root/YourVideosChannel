<?php
	ob_start();
	include('session.php');
?>

<?php include('public/menubar.php'); ?>
<?php include('public/confirm-delete-video.php'); ?>
<?php include('public/footer.php'); ?>